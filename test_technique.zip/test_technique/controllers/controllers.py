# -*- coding: utf-8 -*-
# from odoo import http


# class TestTechnique(http.Controller):
#     @http.route('/test_technique/test_technique/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/test_technique/test_technique/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('test_technique.listing', {
#             'root': '/test_technique/test_technique',
#             'objects': http.request.env['test_technique.test_technique'].search([]),
#         })

#     @http.route('/test_technique/test_technique/objects/<model("test_technique.test_technique"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('test_technique.object', {
#             'object': obj
#         })
