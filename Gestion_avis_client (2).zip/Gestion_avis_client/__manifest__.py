{
    'name': 'Gestion avis client',
    'version': '1.0',
    'summary': 'Un module un module qui permet de gérer les avis avis client',
    'description': """
      Ce module permet de :
       - Créer des avis d'un produit
    """,
    'author': 'Badr AHRIR',
    'category': 'Gestion de avis',
    'depends': ['base'],
    # le module base : contient les fonctionnes minimal
    # res.users , res.partner , gestion multi-société
    # droit d'accés et les groupe
    'data': [
        "security/ir.model.access.csv",
        "views/avis_client_view",
        "views/avis_de_chaque_product",
        "views/avis_client_menu"
    ],
    'demo': [],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
