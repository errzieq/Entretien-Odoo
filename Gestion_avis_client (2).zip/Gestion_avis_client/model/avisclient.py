from odoo import api,models,fields

class AvisClient(models.Model):
    _name = "gestion_avis_client.avis_client"

    products=fields.Many2one("product.template","Products")
    avis=fields.Char(string="Avis client")
    statue_avis=fields.Selection([
        ('rejeter','Rejeter'),
        ('approuver','Approuver'),
    ],default="rejeter",string="status avis")

    def Etat_avis_approuver(self):
        self.write({
            "statue_avis":"approuver"
        })
    def Etat_avis_rejeter(self):
        self.write({
            "statue_avis": "rejeter"
        })