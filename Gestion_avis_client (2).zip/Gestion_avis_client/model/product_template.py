from odoo import fields, models, api



class product_template(models.Model):
    _inherit = "product.template"

    avis_ids = fields.One2many(
        "gestion_avis_client.avis_client",  # modèle lié
        "products",  # champ Many2one dans AvisClient
        string="Avis des clients"
    )
