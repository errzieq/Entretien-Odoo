#-*- coding: utf-8 -*-

from odoo import models, fields, api


class Note_product(models.Model):
    _name = 'avis.product'
    _rec_name ='note'
    _description = 'Avis sur les produits'

    product_id = fields.Many2one('product.template')
    note = fields.Text()
    state = fields.Selection([('approved', u'Approved'), ('rejeter', u'Rejeter'), ], u'Etat',
                             required=True, default='rejeter')
