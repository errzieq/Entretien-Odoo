from . import avis_product
from . import product_template
from . import avis_product_line