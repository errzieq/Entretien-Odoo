
#-*- coding: utf-8 -*-

from odoo import models, fields, api



class Avis_product_line(models.Model):
    _name = 'avis.product.line'
    _description = 'Avis sur les produits'

    avis_product_id = fields.Many2one('avis.product', string="Avis Lignes")
    product_id = fields.Many2one('product.template')
