#-*- coding: utf-8 -*-

from odoo import models, fields, api


class Product_template(models.Model):
    _inherit = 'product.template'
    _description = 'Avis sur les produits'

    avis_product_ids = fields.One2many('avis.product.line','product_id', string="Avis")
