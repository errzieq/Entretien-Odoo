{
    'name': "test_technique",
    'summary': """
       Module avis produits """,
    'description': """
       Module avis produits
    """,
    'author': "ANAS",
    'category': 'Uncategorized',
    'version': '0.1',
    'depends': ['base', 'product','stock'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/product_template.xml',
    ],
}
